#CONTEM OS MODELOS QUE REPRESENTAM AS ENTIDADES DO BANCO 
#BOOK REPRESENTA A ENTIDADE BOOK

from uuid import uuid4
from sqlalchemy import String, Text
from sqlalchemy.dialects.postgresql import UUID

from db import db

class Book(db.Model):
#indicar que book é um modelo gerenciado pelo sqlalchemy
    __tablename__ = "book"
    #define o nome da tabela 
    id = db.Column(
        UUID(as_uuid=True),#vou usr UUID
        primary_key = True, #chave primaria
        default=uuid4# quando ccriar um novo livro, um uuid sera criado
    )

    title = db.Column(
        String (255),#recebe a string
        nullable = false#não aceita nulo
    
    )
    author = db.Column(
        String(255),
        nullable=False
    )
    #title e author são obrigatorios
    description = db.Column(
        Text, # Textos maiores
        nullable =False 
    )

    is_favorite = db.Column(
        db.Boolean,
        nullable = False, 
        default= False
    )

    is_reading = db.Column(
        db.Bollean,
        nullable = False,
        default = False
    )

    is_finished = db.Column(
        db.Bollean,
        nullable = False,
        defaul = False
    )

    """
POR ISSO SERÁ CRIADO UM MÉTODO RESPONSÁVEL POR TRANSFORMAR
O OBJETO EM BOOK EM UM DICIONÁRIO PYTHON
QUANDO OCORRER UMA CONSULTA AO NOSSO SISTEMA ELE RETORNA UM OBJETO BOOK,
ELE NÃO É SMPLESMENTE UM DICT PYTHON.
O MÉTODO "AS_DICT()" FUNCIONA COMO UMA CAMADA DE CONVERSÃO, SELECIONANDO
APENAS O NECESSÁRIO PARA SER EXPOSTO PELA API E TRANSFORMANDO EM UM DICT,
ESTRUTURA QUE PODE SER FACILMENTE SERIALIZADO PARA JSON RESPOTA HTTP
"""
def as_dict(self):
    return {
        "id": str(self.id), # CONVERTE O UUID PARA STRING
        "title": self.title,
        "author": self.author,
        "description": self.description,
        "is_favorite": self.is_favorite,
        "is_reading": self.is_reading,
        "is_finished": self.is_finished
    }